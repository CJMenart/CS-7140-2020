var searchData=
[
  ['xml_5fdeclaration_1151',['XML_DECLARATION',['../classau_1_1id_1_1jericho_1_1lib_1_1html_1_1Tag.html#a4744e8dd000f3009feb1aa0d8513ef13',1,'au::id::jericho::lib::html::Tag']]]
];
