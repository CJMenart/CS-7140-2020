var searchData=
[
  ['verbose_847',['verbose',['../classorg_1_1stathissideris_1_1ascii2image_1_1core_1_1ProcessingOptions.html#a8589638d16f0cfc98a3f6043bf5db886',1,'org::stathissideris::ascii2image::core::ProcessingOptions']]]
];
