var searchData=
[
  ['blankoutputsegment_636',['BlankOutputSegment',['../classau_1_1id_1_1jericho_1_1lib_1_1html_1_1BlankOutputSegment.html#aa9f8801513048617638d03b10f159367',1,'au.id.jericho.lib.html.BlankOutputSegment.BlankOutputSegment(int begin, int end)'],['../classau_1_1id_1_1jericho_1_1lib_1_1html_1_1BlankOutputSegment.html#a4ae13bd06a906f1801ad95463fa73922',1,'au.id.jericho.lib.html.BlankOutputSegment.BlankOutputSegment(Segment segment)']]],
  ['breakintodistinctboundaries_637',['breakIntoDistinctBoundaries',['../classorg_1_1stathissideris_1_1ascii2image_1_1text_1_1CellSet.html#ac7e4079f7ac10ddbc13d4fe2ce4b1313',1,'org.stathissideris.ascii2image.text.CellSet.breakIntoDistinctBoundaries(TextGrid grid)'],['../classorg_1_1stathissideris_1_1ascii2image_1_1text_1_1CellSet.html#ab54733b744c63a5268f0354ec11ff620',1,'org.stathissideris.ascii2image.text.CellSet.breakIntoDistinctBoundaries()']]],
  ['breaktrulymixedboundaries_638',['breakTrulyMixedBoundaries',['../classorg_1_1stathissideris_1_1ascii2image_1_1text_1_1CellSet.html#a5b5ed3674ab77f5871db0ed7eec4350d',1,'org::stathissideris::ascii2image::text::CellSet']]]
];
