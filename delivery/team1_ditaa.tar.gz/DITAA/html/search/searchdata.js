var indexSectionsWithContent =
{
  0: "_abcdefghijklmnopqrstuvx",
  1: "abcdefghijnoprstv",
  2: "abcdefghijlmoprstv",
  3: "_abcdefhiklmnopqrstuvx",
  4: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Pages"
};

